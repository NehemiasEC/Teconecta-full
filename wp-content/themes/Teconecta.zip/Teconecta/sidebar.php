<aside>
    <div class="fb-like" data-href="https://www.facebook.com/teconecta.org/" data-width="250px" data-layout="standard" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>
    <?php
    if(!function_exists("dynamic_sidebar") || !dynamic_sidebar("Primary Sidebar"));
    ?>
</aside>