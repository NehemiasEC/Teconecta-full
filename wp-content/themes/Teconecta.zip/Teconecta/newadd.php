<div class="newadd" id="newadd" >
    <form action="">
        <label for="titulo">Titullo</label>
        <input type="text" id="titulo" required name="titulo" placeholder="Coloca el titulo de tu NewPhoto">
        <label for="localizacion">Localizacion</label>
        <input type="text" id="localizacion" required name="localizacion" placeholder="Donde estas?">
        <button class="plus">Agregar Foto</button>
    </form>
</div>